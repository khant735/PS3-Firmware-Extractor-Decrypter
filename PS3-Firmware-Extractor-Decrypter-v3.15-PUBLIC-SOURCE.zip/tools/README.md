Place separately obtained compatible Windows PS3Tools/scetool executables and required DLLs here. These are not bundled in the public source package.
