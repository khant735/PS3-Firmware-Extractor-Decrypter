$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command gcc -ErrorAction SilentlyContinue)) { throw 'Use MSYS2 UCRT64 with gcc and zlib installed' }
$common = @('tools.c','aes.c','sha1.c','ec.c','bn.c','mingw_mmap.c')
foreach ($name in @('unpkg','unself')) {
  & gcc -O2 -DWIN32 -D_WIN32 -fno-strict-aliasing -o "../tools/$name.exe" @common "$name.c" -lz
  if ($LASTEXITCODE -ne 0) { throw "Build failed: $name" }
}
Write-Host 'Instrumented tools compiled into ../tools'
